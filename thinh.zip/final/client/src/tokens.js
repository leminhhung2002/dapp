export default [
    {
    "price": "0.0001",
    "tokenId": 0,
    "seller": "0x6db64B65E05cFdffcc59aed245B65278E8AaDd79",
    "owner": "0x96305c862FcD7A8E609335973a48C8DB9824c3d4",
    "tokenURI": "https://gateway.pinata.cloud/ipfs/bafybeiawikkpiaqw23mnxzvpmbbczciqpm56cznbdiwy7dr524zoobahiy",
    "name": "ape 1",
    "isListed": true
    },
    {
    "price": "0.0001",
    "tokenId": 1,
    "seller": "0xe5f117D1A8E114B9a47d1a6490b81c85F8124E6E",
    "owner": "0x96305c862FcD7A8E609335973a48C8DB9824c3d4",
    "tokenURI": "https://gateway.pinata.cloud/ipfs/bafybeic5fra4jpqoihch47swqlaxze6z25ujdvg46xvx322ngjzh4xr3ri",
    "name": "ape 2",
    "isListed": true
    }
]
